. /opt/SP/beaoagj/mw_home/wlserver/server/bin/setWLSEnv.sh
cd /opt/SP/app/bea/wlsadm/WLST
clear
java weblogic.WLST Alert_StuckThread_ThreadDumps.py
java weblogic.WLST AdminThreadDump.py
